package com.javiera.alke.model;

public enum TransactionType {
    deposit,
    withdrawal,
    transfer
}
