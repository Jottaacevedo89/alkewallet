package com.javiera.alke.model;

public class TransferForm {
    private String contact;
    private double amount;

    // Getters y setters
    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
